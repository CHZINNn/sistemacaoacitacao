package entidades;

import java.util.Scanner;
public class Produto {
    private String name;
    private double price;
    private int quantity;

    public Produto() {
    }
    public String getNome() {
        return name;
    }
    public void setNome(String nome) {
        this.name = nome;
    }
    public double getPreco() {
        return price;
    }
    public void setPreco(double preco) {
        this.price = preco;
    }
    public int getQuantidade() {
        return quantity;
    }
    public void setQuantidade(int quantidade) {
        this.quantity = quantidade;
    }
    public double calcularValorTotal() {
        return price * quantity;
    }
    public void entrada(int quantidade) {
        if (quantidade > 0) {
            this.quantity += quantidade;
        }
    }
    public void saida(int quantidade) {
        if (quantidade > 0) {
            if (quantidade <= this.quantity) {
                this.quantity -= quantidade;
            }
        }
    }
    public void mostrarDados() {
        System.out.println("\n=== Dados do Produto ===");
        System.out.println("Nome: " + name);
        System.out.printf("Preço: R$ %.2f%n", price);
        System.out.println("Quantidade no estoque: " + quantity);
        System.out.printf("Valor total no estoque: R$ %.2f%n", calcularValorTotal());
        System.out.println("========================\n");
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Produto produto = new Produto();

        System.out.println("Informe os dados do produto:");

        System.out.print("Nome: ");
        produto.setNome(scanner.nextLine());

        while (true) {
            System.out.print("Preço: R$ ");
            String precoInput = scanner.nextLine();
            try {
                double preco = Double.parseDouble(precoInput);
                if (preco >= 0) {
                    produto.setPreco(preco);
                    break;
                }
            } catch (NumberFormatException e) {
            }
        }
        while (true) {
            System.out.print("Quantidade no estoque: ");
            String qtdInput = scanner.nextLine();
            try {
                int qtd = Integer.parseInt(qtdInput);
                if (qtd >= 0) {
                    produto.setQuantidade(qtd);
                    break;
                }
            } catch (NumberFormatException e) {
            }
        }
        System.out.print("Quantidade para entrada no estoque: ");
        while (true) {
            String entradaInput = scanner.nextLine();
            try {
                int entrada = Integer.parseInt(entradaInput);
                produto.entrada(entrada);
                break;
            } catch (NumberFormatException e) {
            }
        }
        System.out.println("Dados do produto após a entrada:");
        produto.mostrarDados();

        System.out.print("Quantidade para saída no estoque: ");
        while (true) {
            String saidaInput = scanner.nextLine();
            try {
                int saida = Integer.parseInt(saidaInput);
                produto.saida(saida);
                break;
            } catch (NumberFormatException e) {
            }
        }
        System.out.println("Dados do produto após a saída:");
        produto.mostrarDados();
    }
}
